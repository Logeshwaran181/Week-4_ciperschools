#include<iostream>
using namespace std;

//this is how node of tree is defined
class Node{
	public:
		int data;
		Node* left;
		Node* right;
		
		//since each node has the address to node corresponding to the left and dright of root we are able to access the whole tree from the root node
		
};

int main(){
	string CEO;
	string PA,CFO;
	return 0;
}